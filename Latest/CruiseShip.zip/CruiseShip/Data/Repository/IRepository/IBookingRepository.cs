﻿using CruiseShip.Models;

namespace CruiseShip.Data.Repository.IRepository
{
    public interface IBookingRepository : IRepository<Booking>
    {
        Task Update(Booking obj);
    }
}
